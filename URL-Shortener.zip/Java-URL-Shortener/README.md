# Java URL Shortener

A simple URL Shortener built using Java. The project generates short IDs for long URLs, stores URL mappings locally, provides an HTTP redirect server, and tracks click statistics.

## Features

- Generate random 6-character short IDs
- Validate HTTP/HTTPS URLs
- Store URL mappings in a local text file
- Run a local HTTP server on port `8080`
- Redirect short URLs to original URLs
- Track click counts
- View URL statistics
- Detect short-ID collisions

## Technologies Used

- Java
- Java Collections (`HashMap`)
- Java File I/O
- Java HTTP Server (`com.sun.net.httpserver`)
- Command Line Interface

## Project Structure

```text
Java-URL-Shortener/
├── src/
│   └── URLShortener.java
├── data/
│   └── url.txt
├── README.md
├── .gitignore
└── LICENSE
```

## How to Run

### 1. Compile

From the project root:

```bash
javac -d out src/URLShortener.java
```

### 2. Run

```bash
java -cp out URLShortener
```

The server starts at:

```text
http://localhost:8080
```

### 3. Use the menu

```text
===== URL SHORTENER =====
1. Shorten URL
2. Find Original URL
3. Show Statistics
4. Exit
```

Choose `1`, enter a URL such as:

```text
https://www.google.com
```

The application generates a short ID such as:

```text
Ab12Xy
```

You can then open:

```text
http://localhost:8080/Ab12Xy
```

The server redirects the request to the original URL and increments the click count.

## Example

```text
Enter choice: 1
Enter Long URL: https://www.google.com

URL saved successfully!
Short ID: Ab12Xy
Short Link: http://localhost:8080/Ab12Xy
```

## Learning Outcomes

- Java HashMap usage
- File handling and persistent storage
- HTTP server basics
- URL redirection
- Input validation
- Exception handling
- Basic application design

## Limitations

This is an educational/local project. It stores data in a text file and runs on localhost. It is not designed for production-scale traffic or distributed deployment.

## Future Improvements

- Database integration using MySQL/PostgreSQL
- REST API
- Web-based frontend
- QR code generation
- User authentication
- Custom aliases
- Expiring links
- Analytics dashboard
